package controller;

public class MainMenuController {
    public void goToProfileMenu(){}
    public void goToGameMenu(){}
    public void logout(){}
}
