package model;

public class SpellUnit extends Unit{
}
