package model;

public class SiegeUnit extends WarUnit {
}
