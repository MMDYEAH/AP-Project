package model;

public class RangedCombatUnit extends WarUnit {
}
