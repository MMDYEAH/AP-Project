package model;

public class ClearWeather extends WeatherCard{
    public ClearWeather(String name,String path) {
        super(name,path);
    }

    @Override
    public void apply() {

    }
    public void unApply(){

    }
}
