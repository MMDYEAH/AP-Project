package model;

public class DiscardPileUnit extends Unit{
}
