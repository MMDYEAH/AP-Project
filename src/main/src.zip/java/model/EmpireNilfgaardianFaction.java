package model;

import java.util.ArrayList;

public class EmpireNilfgaardianFaction extends Faction{
    //TODO: makeCards and add to faction leader card and unit cards
    public EmpireNilfgaardianFaction(ArrayList<FactionLeaderCard> factionLeaderCards, ArrayList<Card> unitCards) {
        super("EmpireNilfgaardian", factionLeaderCards, unitCards);

    }

    @Override
    public void apply() {

    }

}
