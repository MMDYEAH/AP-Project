package model;

public class DeckUnit extends Unit{
}
