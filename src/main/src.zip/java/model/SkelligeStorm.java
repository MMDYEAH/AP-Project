package model;

public class SkelligeStorm extends WeatherCard{
    public SkelligeStorm(String name,String path) {
        super(name,path);
    }

    @Override
    public void apply() {

    }
    public void unApply(){

    }
}
