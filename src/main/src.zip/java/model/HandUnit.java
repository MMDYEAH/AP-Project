package model;

import java.util.ArrayList;

public class HandUnit extends Unit{
}
