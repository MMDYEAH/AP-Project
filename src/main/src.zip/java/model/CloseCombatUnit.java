package model;

public class CloseCombatUnit extends WarUnit {
}
