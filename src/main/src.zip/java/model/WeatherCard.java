package model;

public abstract class WeatherCard extends Card{
    public WeatherCard(String name, String path) {
        super(name,path);
    }

    @Override
    public void apply() {

    }
    public void unApply(){

    }
}
